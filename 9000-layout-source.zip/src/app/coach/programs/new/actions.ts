"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createCoachAdminClient } from "@/lib/supabase/admin";

type ProgramValues = {
  name: string;
  goal: string;
  description: string;
  durationWeeks: string;
  sessionsPerWeek: string;
};

export type ProgramFormState = {
  error: string;
  values?: ProgramValues;
};

export async function createProgram(
  _previousState: ProgramFormState,
  formData: FormData,
): Promise<ProgramFormState> {
  const programId = String(formData.get("programId") ?? "");

  const values: ProgramValues = {
    name: String(formData.get("name") ?? "").trim(),
    goal: String(formData.get("goal") ?? "").trim(),
    description: String(formData.get("description") ?? "").trim(),
    durationWeeks: String(formData.get("durationWeeks") ?? ""),
    sessionsPerWeek: String(formData.get("sessionsPerWeek") ?? ""),
  };

  const fail = (error: string): ProgramFormState => ({
    error,
    values,
  });

  const validId =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  if (!validId.test(programId)) {
    return fail("Please refresh the page and try again.");
  }

  if (!values.name || values.name.length > 100) {
    return fail("Enter a program name between 1 and 100 characters.");
  }

  if (values.goal.length > 300) {
    return fail("Keep the goal under 300 characters.");
  }

  if (values.description.length > 2000) {
    return fail("Keep the description under 2,000 characters.");
  }

  const durationWeeks = Number(values.durationWeeks);
  const sessionsPerWeek = Number(values.sessionsPerWeek);

  if (
    !Number.isInteger(durationWeeks) ||
    durationWeeks < 1 ||
    durationWeeks > 52
  ) {
    return fail("Choose a duration between 1 and 52 whole weeks.");
  }

  if (
    !Number.isInteger(sessionsPerWeek) ||
    sessionsPerWeek < 1 ||
    sessionsPerWeek > 7
  ) {
    return fail("Choose between 1 and 7 workouts per week.");
  }

  try {
    const admin = await createCoachAdminClient();
    const coachId = process.env.COACH_USER_ID!;

    const { error } = await admin.from("programs").insert({
      id: programId,
      name: values.name,
      goal: values.goal,
      description: values.description,
      duration_weeks: durationWeeks,
      sessions_per_week: sessionsPerWeek,
      status: "draft",
      created_by: coachId,
    });

    if (error) {
      if (error.code !== "23505") {
        return fail(
          "Could not confirm the save. You can retry this form or check your programs.",
        );
      }

      // Repeating the same submission after a lost response
      // should not create another program.
      const { data: existing, error: lookupError } = await admin
        .from("programs")
        .select(
          "id, name, goal, description, duration_weeks, sessions_per_week",
        )
        .eq("id", programId)
        .eq("created_by", coachId)
        .maybeSingle();

      if (lookupError || !existing) {
        return fail("Could not save the program. Please try again.");
      }

      const sameDetails =
        existing.name === values.name &&
        existing.goal === values.goal &&
        existing.description === values.description &&
        existing.duration_weeks === durationWeeks &&
        existing.sessions_per_week === sessionsPerWeek;

      if (!sameDetails) {
        return fail(
          "This draft was already created by an earlier attempt. Go back to Programs to view it. Your latest changes have not been saved.",
        );
      }
    }
  } catch {
    return fail(
      "Could not complete the request. Check your connection and coach sign-in, then retry.",
    );
  }

  revalidatePath("/coach/programs");
  redirect("/coach/programs");
}