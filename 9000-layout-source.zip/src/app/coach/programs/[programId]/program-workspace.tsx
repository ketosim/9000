import { randomUUID } from "node:crypto";
import Link from "next/link";
import { notFound } from "next/navigation";
import { createCoachAdminClient } from "@/lib/supabase/admin";
import { BuilderForm } from "./builder/builder-form";
import { WorkoutOrderControls } from "./builder/workout-order-controls";
import { WorkoutEditor } from "./workouts/[workoutId]/workout-editor";
import { WorkspaceSelect } from "./workspace-select";
import { selectWorkspace, type WorkspaceWeek } from "./workspace-selection";
import styles from "./program-workspace.module.css";

type Props = { programId: string; weekId?: string; workoutId?: string };
const uuidPattern =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function ProgramWorkspace({
  programId,
  weekId,
  workoutId,
}: Props) {
  const supabase = await createCoachAdminClient();
  if (
    ![
      programId,
      ...(weekId ? [weekId] : []),
      ...(workoutId ? [workoutId] : []),
    ].every((id) => uuidPattern.test(id))
  )
    notFound();

  const { data: program, error: programError } = await supabase
    .from("programs")
    .select("id, name, duration_weeks, sessions_per_week, status")
    .eq("id", programId)
    .eq("created_by", process.env.COACH_USER_ID!)
    .maybeSingle();
  if (programError) throw new Error("Could not load the program.");
  if (!program) notFound();

  const { data, error } = await supabase
    .from("program_weeks")
    .select(
      `id, week_number, focus, coaching_notes, is_deload,
      program_workouts (id, name, position, estimated_minutes, warmup_notes)`,
    )
    .eq("program_id", programId)
    .order("week_number");
  if (error) throw new Error("Could not load the program weeks.");

  const selection = selectWorkspace(
    (data ?? []) as WorkspaceWeek[],
    weekId,
    workoutId,
  );
  if (!selection) notFound();
  const { weeks, week, workouts, workout } = selection;
  const base = `/coach/programs/${programId}`;
  const availableWeeks = Array.from(
    { length: program.duration_weeks },
    (_, i) => i + 1,
  ).filter((number) => !weeks.some((item) => item.week_number === number));
  const order = workouts.map((item) => item.id);

  return (
    <main className={`${styles.workspace} py-6 sm:py-8`}>
      <header className="mb-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs uppercase tracking-[0.18em] text-muted">
            {program.status}
          </p>
          <Link
            href={`${base}/details`}
            className="inline-flex min-h-11 items-center rounded-md px-2 text-sm text-hal-red-bright hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-400"
          >
            Edit details
          </Link>
        </div>
        <h1 className="mt-2 text-3xl font-semibold tracking-tight [overflow-wrap:anywhere] sm:text-4xl">
          {program.name}
        </h1>
        <p className="mt-3 text-sm text-muted">
          {program.duration_weeks} weeks · {program.sessions_per_week} planned
          workouts per week
        </p>
      </header>

      {week ? (
        <>
          <section
            aria-label="Selected week"
            className="mb-6 border-y border-white/10 py-4"
          >
            <div className="flex flex-wrap items-end justify-between gap-4">
              <WorkspaceSelect
                label="Week"
                value={`${base}/builder?week=${week.id}`}
                options={weeks.map((item) => ({
                  value: `${base}/builder?week=${item.id}`,
                  label: `Week ${item.week_number}${item.is_deload ? " · Deload" : ""}`,
                }))}
              />
              <p className="pb-3 text-sm text-muted">
                {workouts.length}{" "}
                {workouts.length === 1 ? "workout" : "workouts"}
              </p>
            </div>
            {week.focus && (
              <p className="mt-4 text-sm font-medium [overflow-wrap:anywhere]">
                {week.focus}
              </p>
            )}
            {week.coaching_notes && (
              <details className="mt-2">
                <summary className="inline-flex min-h-11 cursor-pointer items-center text-sm text-muted">
                  Week notes
                </summary>
                <p className="mt-1 whitespace-pre-line text-sm text-muted [overflow-wrap:anywhere]">
                  {week.coaching_notes}
                </p>
              </details>
            )}
          </section>

          <div className={styles.columns}>
            <aside
              key={`workout-list-${week.id}`}
              aria-label={`Workouts for week ${week.week_number}`}
              className="min-w-0"
            >
              <div className={styles.workoutCards}>
                <h2 className="mb-3 text-lg font-semibold">Workouts</h2>
                <ol className="space-y-3">
                  {workouts.map((item) => (
                    <li
                      key={item.id}
                      className={`min-w-0 rounded-xl border p-3 ${item.id === workout?.id ? "border-hal-red/60 bg-panel-light" : "border-white/10 bg-panel"}`}
                    >
                      <Link
                        href={`${base}/workouts/${item.id}`}
                        aria-current={
                          item.id === workout?.id ? "page" : undefined
                        }
                        className="block min-h-11 rounded-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-400"
                      >
                        <span className="block text-xs text-muted">
                          Workout {item.position}
                          {item.estimated_minutes !== null
                            ? ` · ${item.estimated_minutes} min`
                            : ""}
                        </span>
                        <span className="mt-2 block font-semibold [overflow-wrap:anywhere]">
                          {item.name}
                        </span>
                      </Link>
                      <WorkoutOrderControls
                        programId={programId}
                        weekId={week.id}
                        workoutId={item.id}
                        workoutName={item.name}
                        order={order}
                      />
                    </li>
                  ))}
                </ol>
              </div>

              {workout && (
                <div className={styles.workoutPicker}>
                  <WorkspaceSelect
                    label="Workout"
                    value={`${base}/workouts/${workout.id}`}
                    options={workouts.map((item) => ({
                      value: `${base}/workouts/${item.id}`,
                      label: `${item.position}. ${item.name}`,
                    }))}
                  />
                  <WorkoutOrderControls
                    programId={programId}
                    weekId={week.id}
                    workoutId={workout.id}
                    workoutName={workout.name}
                    order={order}
                  />
                </div>
              )}

              {workouts.length < 7 ? (
                <details className="mt-4 rounded-xl border border-white/10 bg-panel p-3">
                  <summary className="min-h-11 cursor-pointer py-3 text-sm font-medium text-hal-red-bright">
                    Add workout
                  </summary>
                  <div className={styles.formStack}>
                    <BuilderForm
                      key={`workout-form-${week.id}-${workouts.length}`}
                      mode="workout"
                      programId={programId}
                      weekId={week.id}
                      itemId={randomUUID()}
                      submitLabel="Save workout"
                      fields={[
                        {
                          name: "name",
                          label: "Workout name",
                          required: true,
                          maxLength: 100,
                        },
                        {
                          name: "estimatedMinutes",
                          label: "Estimated minutes (optional)",
                          type: "number",
                          min: 1,
                          max: 300,
                        },
                        {
                          name: "warmupNotes",
                          label: "Warm-up notes (optional)",
                          type: "textarea",
                          maxLength: 2000,
                        },
                      ]}
                    />
                  </div>
                </details>
              ) : (
                <p className="mt-4 text-xs text-muted">Seven workouts added.</p>
              )}
            </aside>

            <div
              id="workout-editor"
              key={`workout-editor-${workout?.id ?? week.id}`}
              className="min-w-0 scroll-mt-6"
            >
              {workout ? (
                <WorkoutEditor programId={programId} workoutId={workout.id} />
              ) : (
                <section className="hal-panel rounded-xl p-5">
                  <h2 className="text-xl font-semibold">
                    No workouts in this week yet
                  </h2>
                  <p className="mt-2 text-sm text-muted">
                    Choose Add workout to start building this week.
                  </p>
                </section>
              )}
            </div>
          </div>
        </>
      ) : (
        <section className="hal-panel rounded-xl p-5">
          <h2 className="text-xl font-semibold">No weeks yet</h2>
          <p className="mt-2 text-sm text-muted">
            Add your first week below, then add its workouts.
          </p>
        </section>
      )}

      {availableWeeks.length > 0 && (
        <details
          id="add-week"
          className="hal-panel mt-8 rounded-xl p-4 sm:p-5"
          open={weeks.length === 0}
        >
          <summary className="min-h-11 cursor-pointer py-3 font-semibold">
            Add week
          </summary>
          <div className="max-w-2xl">
            <BuilderForm
              key={`week-form-${weeks.length}`}
              mode="week"
              programId={programId}
              itemId={randomUUID()}
              submitLabel="Save week"
              fields={[
                {
                  name: "weekNumber",
                  label: "Week",
                  required: true,
                  defaultValue: String(availableWeeks[0]),
                  options: availableWeeks.map((number) => ({
                    value: String(number),
                    label: `Week ${number}`,
                  })),
                },
                {
                  name: "focus",
                  label: "Week focus (optional)",
                  maxLength: 200,
                },
                {
                  name: "coachingNotes",
                  label: "Coaching notes (optional)",
                  type: "textarea",
                  maxLength: 2000,
                },
              ]}
            />
          </div>
        </details>
      )}
    </main>
  );
}
