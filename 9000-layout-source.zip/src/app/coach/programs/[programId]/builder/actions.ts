"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createCoachAdminClient } from "@/lib/supabase/admin";

export type BuilderState = {
  error: string;
  values: Record<string, string>;
};

export type MoveWorkoutState = {
  error: string;
  message: string;
};

const uuidPattern =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function createBuilderItem(
  _previousState: BuilderState,
  formData: FormData,
): Promise<BuilderState> {
  const read = (name: string) => String(formData.get(name) ?? "").trim();
  const mode = read("mode");
  const programId = read("programId");
  const weekId = read("weekId");
  const itemId = read("itemId");
  const values = {
    weekNumber: read("weekNumber"),
    focus: read("focus"),
    coachingNotes: read("coachingNotes"),
    name: read("name"),
    estimatedMinutes: read("estimatedMinutes"),
    warmupNotes: read("warmupNotes"),
  };
  const fail = (error: string): BuilderState => ({ error, values });

  if (
    !uuidPattern.test(programId) ||
    !uuidPattern.test(itemId) ||
    !["week", "workout"].includes(mode)
  ) {
    return fail("This form is invalid. Refresh the page and try again.");
  }
  if (mode === "workout" && !uuidPattern.test(weekId)) {
    return fail("This week is invalid. Refresh the page and try again.");
  }

    const destination =
    mode === "week"
        ? `/coach/programs/${programId}/builder?week=${itemId}`
        : `/coach/programs/${programId}/workouts/${itemId}`;
  try {
    const supabase = await createCoachAdminClient();
    const { data: program, error: programError } = await supabase
      .from("programs")
      .select("id, duration_weeks")
      .eq("id", programId)
      .eq("created_by", process.env.COACH_USER_ID!)
      .maybeSingle();

    if (programError)
      return fail("Could not load the program. Please try again.");
    if (!program) return fail("This program is unavailable for your account.");

    if (mode === "week") {
      const weekNumber = Number(values.weekNumber);
      if (
        !/^\d+$/.test(values.weekNumber) ||
        weekNumber < 1 ||
        weekNumber > program.duration_weeks
      ) {
        return fail(`Choose a week between 1 and ${program.duration_weeks}.`);
      }
      if (values.focus.length > 200 || values.coachingNotes.length > 2000) {
        return fail("The focus or coaching notes are too long.");
      }
      const payload = {
        id: itemId,
        program_id: programId,
        week_number: weekNumber,
        focus: values.focus,
        coaching_notes: values.coachingNotes,
      };
      const { error: insertError } = await supabase
        .from("program_weeks")
        .insert(payload);
      if (insertError) {
        if (insertError.code !== "23505") {
          return fail(
            "Could not confirm the save. Retry, or refresh to check.",
          );
        }
        const { data: existing, error: existingError } = await supabase
          .from("program_weeks")
          .select("*")
          .eq("id", itemId)
          .eq("program_id", programId)
          .maybeSingle();
        const sameItem =
          !existingError &&
          existing &&
          Object.entries(payload).every(
            ([key, value]) => existing[key] === value,
          );
        if (!sameItem) {
          return fail(
            "That week may already exist. Refresh to check before adding another.",
          );
        }
      }
    } else {
      const minutes = values.estimatedMinutes
        ? Number(values.estimatedMinutes)
        : null;
      if (!values.name || values.name.length > 100) {
        return fail("Enter a workout name of 1–100 characters.");
      }
      if (
        minutes !== null &&
        (!/^\d+$/.test(values.estimatedMinutes) || minutes < 1 || minutes > 300)
      ) {
        return fail("Enter a duration between 1 and 300 minutes.");
      }
      if (values.warmupNotes.length > 2000) {
        return fail("Keep warm-up notes within 2,000 characters.");
      }

      // The database chooses the next position; no position is accepted from the form.
      const { error } = await supabase.rpc("coach_append_workout", {
        p_coach_id: process.env.COACH_USER_ID!,
        p_program_id: programId,
        p_week_id: weekId,
        p_item_id: itemId,
        p_name: values.name,
        p_estimated_minutes: minutes,
        p_warmup_notes: values.warmupNotes,
      });
      if (error) {
        if (error.message === "WEEK_FULL")
          return fail("This week already has seven workouts.");
        if (error.message === "WEEK_UNAVAILABLE")
          return fail("Could not find this week in your program.");
        if (error.message === "ITEM_CONFLICT")
          return fail(
            "This form was already used. Refresh before adding another workout.",
          );
        console.error("Append workout failed:", {
          code: error.code,
          message: error.message,
        });
        return fail("Could not confirm the save. Retry, or refresh to check.");
      }
    }
  } catch {
    return fail(
      "Could not confirm the save. Check your connection and coach sign-in, then retry.",
    );
  }

  revalidatePath(`/coach/programs/${programId}`, "layout");
  redirect(destination);
}

export async function moveWorkout(
  _previousState: MoveWorkoutState,
  formData: FormData,
): Promise<MoveWorkoutState> {
  const read = (name: string) => String(formData.get(name) ?? "").trim();
  const programId = read("programId");
  const weekId = read("weekId");
  const workoutId = read("workoutId");
  const direction = read("direction");
  const fail = (error: string): MoveWorkoutState => ({ error, message: "" });

  if (
    ![programId, weekId, workoutId].every((id) => uuidPattern.test(id)) ||
    !["up", "down"].includes(direction)
  ) {
    return fail("This move is invalid. Refresh and try again.");
  }
  let expectedOrder: string[];
  try {
    const parsed: unknown = JSON.parse(read("expectedOrder"));
    if (
      !Array.isArray(parsed) ||
      parsed.length < 1 ||
      parsed.length > 7 ||
      !parsed.every((id) => typeof id === "string" && uuidPattern.test(id)) ||
      new Set(parsed).size !== parsed.length ||
      !parsed.includes(workoutId)
    ) {
      return fail("This workout list is invalid. Refresh and try again.");
    }
    expectedOrder = parsed;
  } catch {
    return fail("This workout list is invalid. Refresh and try again.");
  }

  try {
    // Verifies the signed-in coach on every call; the RPC also checks ownership.
    const supabase = await createCoachAdminClient();
    const { error } = await supabase.rpc("coach_move_workout", {
      p_coach_id: process.env.COACH_USER_ID!,
      p_program_id: programId,
      p_week_id: weekId,
      p_workout_id: workoutId,
      p_direction: direction,
      p_expected_order: expectedOrder,
    });
    if (error) {
      if (error.message === "ORDER_CHANGED") {
        revalidatePath(`/coach/programs/${programId}`, "layout");
        return fail(
          "The order changed since this page loaded. Check the current order before moving again.",
        );
      }
      if (["WEEK_UNAVAILABLE", "WORKOUT_UNAVAILABLE"].includes(error.message)) {
        return fail(
          "This workout is unavailable in your program. Refresh the page.",
        );
      }
      console.error("Move workout failed:", {
        code: error.code,
        message: error.message,
      });
      return fail(
        "Could not confirm the move. Refresh to check the order before trying again.",
      );
    }
  } catch {
    return fail(
      "Could not confirm the move. Check your connection and coach sign-in, then refresh.",
    );
  }

  revalidatePath(`/coach/programs/${programId}`, "layout");
  return { error: "", message: "Workout order saved." };
}
