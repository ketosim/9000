"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getOwnedWorkout } from "./access";

export type DeleteState = {
  error: string;
};

export async function deleteWorkoutItem(
  _previousState: DeleteState,
  formData: FormData,
): Promise<DeleteState> {
  const read = (name: string) =>
    String(formData.get(name) ?? "").trim();

  const programId = read("programId");
  const workoutId = read("workoutId");
  const exerciseId = read("exerciseId");
  const itemId = read("itemId");
  const mode = read("mode");

  const uuid =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  if (
    !uuid.test(itemId) ||
    !["exercise", "set"].includes(mode) ||
    (mode === "set" && !uuid.test(exerciseId))
  ) {
    return { error: "Invalid item. Refresh the page and try again." };
  }

  try {
    const context = await getOwnedWorkout(programId, workoutId);

    if (!context) {
      return { error: "This workout is unavailable for your account." };
    }

    const { supabase } = context;

    if (mode === "exercise") {
      const { error } = await supabase
        .from("program_exercises")
        .delete()
        .eq("id", itemId)
        .eq("workout_id", workoutId);

      if (error) {
        return { error: "Could not delete the exercise. Please retry." };
      }
    } else {
      const { data: exercise, error: exerciseError } = await supabase
        .from("program_exercises")
        .select("id")
        .eq("id", exerciseId)
        .eq("workout_id", workoutId)
        .maybeSingle();

      if (exerciseError || !exercise) {
        return {
          error: "This exercise is unavailable. Refresh the page.",
        };
      }

      const { error } = await supabase
        .from("program_sets")
        .delete()
        .eq("id", itemId)
        .eq("exercise_id", exerciseId);

      if (error) {
        return { error: "Could not delete the set. Please retry." };
      }
    }
  } catch {
    return {
      error:
        "Could not confirm deletion. Check your connection, then refresh.",
    };
  }

  const path = `/coach/programs/${programId}/workouts/${workoutId}`;

  revalidatePath(path);

  redirect(
    mode === "set"
      ? `${path}#exercise-${exerciseId}`
      : path,
  );
}