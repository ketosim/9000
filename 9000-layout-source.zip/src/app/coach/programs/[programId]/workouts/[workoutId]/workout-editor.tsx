import { randomUUID } from "node:crypto";
import { notFound } from "next/navigation";
import { getOwnedWorkout } from "./access";
import { WorkoutForm } from "./workout-form";
import { DeleteControl } from "./delete-control";
import { EditWorkoutItem } from "./edit-controls";
type PrescribedSet = {
  id: string;
  set_number: number;
  set_type: string;
  reps_min: number;
  reps_max: number;
  target_load: number | null;
  rir: number | null;
  rest_seconds: number | null;
  side_override: string | null;
  notes: string;
};
type Exercise = {
  id: string;
  name: string;
  position: number;
  variation: string;
  target_muscles: string;
  machine_settings: string;
  attachment: string;
  setup_instructions: string;
  side: string;
  load_convention: string;
  load_unit: string;
  coaching_cues: string;
  exercise_group: string;
  coach_notes: string;
  program_sets: PrescribedSet[];
};
const sideOptions = [
  { value: "both", label: "Both sides together" },
  { value: "alternating", label: "Alternating sides" },
  { value: "each_side", label: "Each side separately" },
];
const loadOptions = [
  { value: "total", label: "Total weight" },
  { value: "per_dumbbell", label: "Per dumbbell" },
  { value: "added_plates", label: "Added plates" },
  { value: "machine_display", label: "Machine display" },
  { value: "assistance", label: "Assistance weight" },
  { value: "bodyweight", label: "Bodyweight" },
];
const setOptions = [
  { value: "working", label: "Working" },
  { value: "warmup", label: "Warm-up" },
  { value: "top", label: "Top set" },
  { value: "backoff", label: "Back-off" },
  { value: "drop", label: "Drop set" },
];
function availableNumbers(used: number[]) {
  return Array.from({ length: 50 }, (_, index) => index + 1)
    .filter((number) => !used.includes(number))
    .map((number) => ({
      value: String(number),
      label: String(number),
    }));
}
type Props = { programId: string; workoutId: string };
export async function WorkoutEditor({ programId, workoutId }: Props) {
  const context = await getOwnedWorkout(programId, workoutId);
  if (!context) notFound();
  const { supabase, workout, week } = context;
  const { data, error } = await supabase
    .from("program_exercises")
    .select("*, program_sets(*)")
    .eq("workout_id", workoutId)
    .order("position");
  if (error) {
    throw new Error("Could not load exercises.");
  }
  const exercises = (data ?? []) as Exercise[];
  const exerciseNumbers = availableNumbers(
    exercises.map((exercise) => exercise.position),
  );
  return (
    <section aria-labelledby="workout-heading" className="min-w-0">
      <div className="min-w-0">
        <header>
          <p className="text-xs uppercase tracking-[0.16em] text-hal-red-bright">
            Week {week.week_number} · Workout {workout.position}
          </p>
          <h2
            id="workout-heading"
            className="mt-3 text-2xl font-semibold [overflow-wrap:anywhere] sm:text-3xl"
          >
            {workout.name}
          </h2>
          {workout.warmup_notes && (
            <div className="mt-5 rounded-lg border border-white/10 p-4">
              <p className="text-xs text-muted">Warm-up</p>
              <p className="mt-2 whitespace-pre-line text-sm [overflow-wrap:anywhere]">
                {workout.warmup_notes}
              </p>
            </div>
          )}
        </header>
        <section className="mt-8 space-y-5" aria-label="Exercises">
          {exercises.length === 0 && (
            <p className="text-sm text-muted">
              No exercises yet. Add your first exercise below.
            </p>
          )}
          {exercises.map((exercise) => {
            const sets = [...exercise.program_sets].sort(
              (a, b) => a.set_number - b.set_number,
            );
            const setNumbers = availableNumbers(
              sets.map((set) => set.set_number),
            );
            const details = [
              ["Variation", exercise.variation],
              ["Target muscles", exercise.target_muscles],
              ["Machine settings", exercise.machine_settings],
              ["Attachment", exercise.attachment],
              ["Setup", exercise.setup_instructions],
              [
                "Side",
                sideOptions.find((option) => option.value === exercise.side)
                  ?.label ?? exercise.side,
              ],
              [
                "Load convention",
                loadOptions.find(
                  (option) => option.value === exercise.load_convention,
                )?.label ?? exercise.load_convention,
              ],
              ["Coaching cues", exercise.coaching_cues],
              ["Superset / circuit group", exercise.exercise_group],
              ["Coach notes", exercise.coach_notes],
            ].filter(([, value]) => Boolean(value));
            return (
              <article
                key={exercise.id}
                id={`exercise-${exercise.id}`}
                className="hal-panel scroll-mt-6 rounded-xl p-4 sm:p-6"
              >
                <p className="text-xs text-muted">
                  Exercise {exercise.position}
                </p>
                <h3 className="mt-2 text-2xl font-semibold [overflow-wrap:anywhere]">
                  {exercise.name}
                </h3>
                <EditWorkoutItem
                  mode="exercise"
                  programId={programId}
                  workoutId={workoutId}
                  item={exercise}
                />
                <DeleteControl
                  mode="exercise"
                  programId={programId}
                  workoutId={workoutId}
                  itemId={exercise.id}
                  label={exercise.name}
                  setCount={sets.length}
                />
                <details className="mt-3">
                  <summary className="min-h-11 cursor-pointer py-3 text-sm text-muted">
                    Exercise details
                  </summary>
                  <dl className="grid gap-4 py-3 sm:grid-cols-2">
                    {details.map(([label, value]) => (
                      <div key={label}>
                        <dt className="text-xs text-muted">{label}</dt>
                        <dd className="mt-1 whitespace-pre-line text-sm [overflow-wrap:anywhere]">
                          {value}
                        </dd>
                      </div>
                    ))}
                  </dl>
                </details>
                <div className="mt-4 space-y-3">
                  {sets.length === 0 && (
                    <p className="text-sm text-muted">
                      No prescribed sets yet.
                    </p>
                  )}
                  {sets.map((set) => (
                    <div
                      key={set.id}
                      className="rounded-lg border border-white/10 bg-black/30 p-4"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="text-sm font-medium">
                          Set {set.set_number}
                        </p>
                        <p className="text-xs text-muted">
                          {setOptions.find(
                            (option) => option.value === set.set_type,
                          )?.label ?? set.set_type}
                        </p>
                      </div>
                      <dl className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
                        <div>
                          <dt className="text-xs text-muted">Reps</dt>
                          <dd className="mt-1 font-medium [overflow-wrap:anywhere]">
                            {set.reps_min === set.reps_max
                              ? set.reps_min
                              : `${set.reps_min}–${set.reps_max}`}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-xs text-muted">Load</dt>
                          <dd className="mt-1 font-medium [overflow-wrap:anywhere]">
                            {set.target_load === null
                              ? "—"
                              : `${set.target_load} ${exercise.load_unit}`}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-xs text-muted">RIR</dt>
                          <dd className="mt-1 font-medium [overflow-wrap:anywhere]">
                            {set.rir ?? "—"}
                          </dd>
                        </div>
                        <div>
                          <dt className="text-xs text-muted">Rest</dt>
                          <dd className="mt-1 font-medium [overflow-wrap:anywhere]">
                            {set.rest_seconds === null
                              ? "—"
                              : `${set.rest_seconds}s`}
                          </dd>
                        </div>
                      </dl>
                      {set.side_override && (
                        <p className="mt-3 text-xs text-muted">
                          Side:{" "}
                          {
                            sideOptions.find(
                              (option) => option.value === set.side_override,
                            )?.label
                          }
                        </p>
                      )}
                      {set.notes && (
                        <p className="mt-3 whitespace-pre-line text-sm text-muted [overflow-wrap:anywhere]">
                          {set.notes}
                        </p>
                      )}
                      <EditWorkoutItem
                        mode="set"
                        programId={programId}
                        workoutId={workoutId}
                        exerciseId={exercise.id}
                        item={set}
                        unit={exercise.load_unit}
                      />
                      <DeleteControl
                        mode="set"
                        programId={programId}
                        workoutId={workoutId}
                        exerciseId={exercise.id}
                        itemId={set.id}
                        label={`set ${set.set_number}`}
                      />
                    </div>
                  ))}
                </div>
                {setNumbers.length > 0 && (
                  <details className="mt-5 border-t border-white/10 pt-2">
                    <summary className="min-h-11 cursor-pointer py-3 text-sm font-medium text-hal-red-bright">
                      Add set
                    </summary>
                    <p className="mt-2 text-xs leading-relaxed text-muted">
                      For exact reps, leave maximum reps blank. Leave load blank
                      if no weight is prescribed.
                    </p>
                    <WorkoutForm
                      key={`sets-${sets.length}`}
                      mode="set"
                      programId={programId}
                      workoutId={workoutId}
                      exerciseId={exercise.id}
                      itemId={randomUUID()}
                      submitLabel="Save set"
                      fields={[
                        {
                          name: "set_number",
                          label: "Set number",
                          required: true,
                          defaultValue: setNumbers[0].value,
                          options: setNumbers,
                        },
                        {
                          name: "set_type",
                          label: "Set type",
                          defaultValue: "working",
                          options: setOptions,
                        },
                        {
                          name: "reps_min",
                          label: "Reps / minimum reps",
                          type: "number",
                          required: true,
                          min: 1,
                          max: 1000,
                        },
                        {
                          name: "reps_max",
                          label: "Maximum reps (optional)",
                          type: "number",
                          min: 1,
                          max: 1000,
                        },
                        {
                          name: "target_load",
                          label: `Target load (${exercise.load_unit}, optional)`,
                          type: "number",
                          min: 0,
                          max: 999999.99,
                          step: 0.01,
                        },
                        {
                          name: "rir",
                          label: "RIR (optional)",
                          type: "number",
                          min: 0,
                          max: 10,
                        },
                        {
                          name: "rest_seconds",
                          label: "Rest seconds (optional)",
                          type: "number",
                          min: 0,
                          max: 3600,
                        },
                        {
                          name: "side_override",
                          label: "Side",
                          advanced: true,
                          options: [
                            {
                              value: "",
                              label: "Use exercise setting",
                            },
                            ...sideOptions,
                          ],
                        },
                        {
                          name: "notes",
                          label: "Set notes",
                          type: "textarea",
                          maxLength: 2000,
                          advanced: true,
                        },
                      ]}
                    />
                  </details>
                )}
              </article>
            );
          })}
        </section>
        {exerciseNumbers.length > 0 && (
          <section className="hal-panel mt-6 rounded-xl p-5 sm:p-6">
            <h3 className="text-xl font-semibold">Add exercise</h3>
            <WorkoutForm
              key={`exercises-${exercises.length}`}
              mode="exercise"
              programId={programId}
              workoutId={workoutId}
              itemId={randomUUID()}
              submitLabel="Save exercise"
              fields={[
                {
                  name: "name",
                  label: "Exercise name",
                  required: true,
                  maxLength: 100,
                },
                {
                  name: "position",
                  label: "Exercise number",
                  required: true,
                  defaultValue: exerciseNumbers[0].value,
                  options: exerciseNumbers,
                },
                {
                  name: "load_unit",
                  label: "Weight unit",
                  defaultValue: "kg",
                  options: [
                    { value: "kg", label: "kg" },
                    { value: "lb", label: "lb" },
                  ],
                },
                {
                  name: "load_convention",
                  label: "How weight is recorded",
                  defaultValue: "total",
                  options: loadOptions,
                },
                {
                  name: "variation",
                  label: "Variation",
                  maxLength: 200,
                  advanced: true,
                },
                {
                  name: "target_muscles",
                  label: "Target muscles",
                  maxLength: 200,
                  advanced: true,
                },
                {
                  name: "machine_settings",
                  label: "Machine settings",
                  maxLength: 500,
                  advanced: true,
                },
                {
                  name: "attachment",
                  label: "Attachment",
                  maxLength: 200,
                  advanced: true,
                },
                {
                  name: "setup_instructions",
                  label: "Setup instructions",
                  type: "textarea",
                  maxLength: 2000,
                  advanced: true,
                },
                {
                  name: "side",
                  label: "Side",
                  defaultValue: "both",
                  options: sideOptions,
                  advanced: true,
                },
                {
                  name: "coaching_cues",
                  label: "Coaching cues",
                  type: "textarea",
                  maxLength: 2000,
                  advanced: true,
                },
                {
                  name: "exercise_group",
                  label: "Superset / circuit group",
                  maxLength: 100,
                  advanced: true,
                },
                {
                  name: "coach_notes",
                  label: "Coach notes",
                  type: "textarea",
                  maxLength: 2000,
                  advanced: true,
                },
              ]}
            />
          </section>
        )}
      </div>
    </section>
  );
}
