import { ProgramWorkspace } from "../../program-workspace";

type Props = {
  params: Promise<{
    programId: string;
    workoutId: string;
  }>;
};

export default async function WorkoutEditorPage({
  params,
}: Props) {
  const { programId, workoutId } = await params;

  return (
    <ProgramWorkspace
      programId={programId}
      workoutId={workoutId}
    />
  );
}