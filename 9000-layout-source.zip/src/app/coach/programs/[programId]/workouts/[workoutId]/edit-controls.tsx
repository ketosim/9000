import { WorkoutForm, type Field } from "./workout-form";

type Props = {
  mode: "exercise" | "set";
  programId: string;
  workoutId: string;
  exerciseId?: string;
  item: { id: string };
  unit?: string;
};

const sideOptions = [
  { value: "both", label: "Both sides together" },
  { value: "alternating", label: "Alternating sides" },
  { value: "each_side", label: "Each side separately" },
];

export function EditWorkoutItem({
  mode,
  programId,
  workoutId,
  exerciseId,
  item,
  unit = "kg",
}: Props) {
  const initialValues: Record<string, string> = {};

  for (const [key, value] of Object.entries(item)) {
    if (value === null) {
      initialValues[key] = "";
    } else if (
      typeof value === "string" ||
      typeof value === "number"
    ) {
      initialValues[key] = String(value);
    }
  }

  const fields: Field[] =
    mode === "exercise"
      ? [
          {
            name: "name",
            label: "Exercise name",
            required: true,
            maxLength: 100,
          },
          {
            name: "load_unit",
            label: "Weight unit",
            options: [
              { value: "kg", label: "kg" },
              { value: "lb", label: "lb" },
            ],
          },
          {
            name: "load_convention",
            label: "How weight is recorded",
            options: [
              { value: "total", label: "Total weight" },
              { value: "per_dumbbell", label: "Per dumbbell" },
              { value: "added_plates", label: "Added plates" },
              { value: "machine_display", label: "Machine display" },
              { value: "assistance", label: "Assistance weight" },
              { value: "bodyweight", label: "Bodyweight" },
            ],
          },
          {
            name: "position",
            label: "Exercise number",
            options: [
              {
                value: initialValues.position,
                label: initialValues.position,
              },
            ],
          },
          {
            name: "variation",
            label: "Variation",
            maxLength: 200,
            advanced: true,
          },
          {
            name: "target_muscles",
            label: "Target muscles",
            maxLength: 200,
            advanced: true,
          },
          {
            name: "machine_settings",
            label: "Machine settings",
            maxLength: 500,
            advanced: true,
          },
          {
            name: "attachment",
            label: "Attachment",
            maxLength: 200,
            advanced: true,
          },
          {
            name: "setup_instructions",
            label: "Setup instructions",
            type: "textarea",
            maxLength: 2000,
            advanced: true,
          },
          {
            name: "side",
            label: "Side",
            options: sideOptions,
            advanced: true,
          },
          {
            name: "coaching_cues",
            label: "Coaching cues",
            type: "textarea",
            maxLength: 2000,
            advanced: true,
          },
          {
            name: "exercise_group",
            label: "Superset / circuit group",
            maxLength: 100,
            advanced: true,
          },
          {
            name: "coach_notes",
            label: "Coach notes",
            type: "textarea",
            maxLength: 2000,
            advanced: true,
          },
        ]
      : [
          {
            name: "set_number",
            label: "Set number",
            options: [
              {
                value: initialValues.set_number,
                label: initialValues.set_number,
              },
            ],
          },
          {
            name: "set_type",
            label: "Set type",
            options: [
              { value: "working", label: "Working" },
              { value: "warmup", label: "Warm-up" },
              { value: "top", label: "Top set" },
              { value: "backoff", label: "Back-off" },
              { value: "drop", label: "Drop set" },
            ],
          },
          {
            name: "reps_min",
            label: "Reps / minimum reps",
            type: "number",
            required: true,
            min: 1,
            max: 1000,
          },
          {
            name: "reps_max",
            label: "Maximum reps",
            type: "number",
            min: 1,
            max: 1000,
          },
          {
            name: "target_load",
            label: `Target load (${unit}, optional)`,
            type: "number",
            min: 0,
            max: 999999.99,
            step: 0.01,
          },
          {
            name: "rir",
            label: "RIR (optional)",
            type: "number",
            min: 0,
            max: 10,
          },
          {
            name: "rest_seconds",
            label: "Rest seconds (optional)",
            type: "number",
            min: 0,
            max: 3600,
          },
          {
            name: "side_override",
            label: "Side",
            advanced: true,
            options: [
              { value: "", label: "Use exercise setting" },
              ...sideOptions,
            ],
          },
          {
            name: "notes",
            label: "Set notes",
            type: "textarea",
            maxLength: 2000,
            advanced: true,
          },
        ];

  return (
    <details className="mt-3 border-t border-white/10 pt-1">
      <summary className="min-h-11 cursor-pointer py-3 text-sm font-medium text-hal-red-bright">
        Edit {mode}
      </summary>

      {mode === "exercise" && (
        <p className="mt-2 text-xs leading-relaxed text-muted">
          Changing the weight unit changes the label on existing sets;
          it does not convert their numbers.
        </p>
      )}

      <WorkoutForm
        key={JSON.stringify(initialValues)}
        operation="update"
        mode={mode}
        programId={programId}
        workoutId={workoutId}
        exerciseId={exerciseId}
        itemId={item.id}
        initialValues={initialValues}
        fields={fields}
        submitLabel="Save changes"
      />
    </details>
  );
}