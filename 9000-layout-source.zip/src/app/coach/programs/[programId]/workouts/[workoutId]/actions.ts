"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getOwnedWorkout } from "./access";

export type WorkoutFormState = {
  error: string;
  values: Record<string, string>;
};

export async function addWorkoutItem(
  _previousState: WorkoutFormState,
  formData: FormData,
): Promise<WorkoutFormState> {
  const read = (name: string) =>
    String(formData.get(name) ?? "").trim();

  const values = Object.fromEntries(
    Array.from(formData.entries())
      .filter(([name]) => !name.startsWith("$ACTION_"))
      .map(([name, value]) => [
        name,
        typeof value === "string" ? value.trim() : "",
      ]),
  );

  const fail = (error: string): WorkoutFormState => ({
    error,
    values,
  });

  const programId = read("programId");
  const workoutId = read("workoutId");
  const exerciseId = read("exerciseId");
  const itemId = read("itemId");
  const mode = read("mode");

  const uuid =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  const isInteger = (value: string, min: number, max: number) =>
    /^\d+$/.test(value) &&
    Number(value) >= min &&
    Number(value) <= max;

  if (!uuid.test(itemId) || !["exercise", "set"].includes(mode)) {
    return fail("Invalid form. Refresh the page and try again.");
  }

  let anchor = "";

  try {
    const context = await getOwnedWorkout(programId, workoutId);

    if (!context) {
      return fail("This workout is unavailable for your account.");
    }

    const { supabase } = context;

    let table: "program_exercises" | "program_sets";
    let parentColumn: "workout_id" | "exercise_id";
    let parentId: string;
    let payload: Record<string, string | number | null>;

    if (mode === "exercise") {
      if (!read("name") || read("name").length > 100) {
        return fail("Enter an exercise name of 1–100 characters.");
      }

      if (!isInteger(read("position"), 1, 50)) {
        return fail("Choose an exercise number between 1 and 50.");
      }

      const textLimits = {
        variation: 200,
        target_muscles: 200,
        machine_settings: 500,
        attachment: 200,
        setup_instructions: 2000,
        coaching_cues: 2000,
        exercise_group: 100,
        coach_notes: 2000,
      };

      for (const [field, limit] of Object.entries(textLimits)) {
        if (read(field).length > limit) {
          return fail(
            `${field.replaceAll("_", " ")} must be within ${limit} characters.`,
          );
        }
      }

      const side = read("side") || "both";
      const unit = read("load_unit") || "kg";
      const convention = read("load_convention") || "total";

      if (!["both", "alternating", "each_side"].includes(side)) {
        return fail("Choose a valid side setting.");
      }

      if (!["kg", "lb"].includes(unit)) {
        return fail("Choose kg or lb.");
      }

      if (
        ![
          "total",
          "per_dumbbell",
          "added_plates",
          "machine_display",
          "assistance",
          "bodyweight",
        ].includes(convention)
      ) {
        return fail("Choose a valid load convention.");
      }

      table = "program_exercises";
      parentColumn = "workout_id";
      parentId = workoutId;

      payload = {
        id: itemId,
        workout_id: workoutId,
        name: read("name"),
        position: Number(read("position")),
        side,
        load_unit: unit,
        load_convention: convention,
      };

      for (const field of Object.keys(textLimits)) {
        payload[field] = read(field);
      }

      anchor = `exercise-${itemId}`;
    } else {
      if (!uuid.test(exerciseId)) {
        return fail("Invalid exercise. Refresh the page.");
      }

      const { data: exercise, error: exerciseError } = await supabase
        .from("program_exercises")
        .select("id")
        .eq("id", exerciseId)
        .eq("workout_id", workoutId)
        .maybeSingle();

      if (exerciseError || !exercise) {
        return fail("Could not find this exercise in your workout.");
      }

      if (!isInteger(read("set_number"), 1, 50)) {
        return fail("Choose a set number between 1 and 50.");
      }

      const setType = read("set_type");

      if (
        !["warmup", "working", "top", "backoff", "drop"].includes(
          setType,
        )
      ) {
        return fail("Choose a valid set type.");
      }

      const minReps = read("reps_min");
      const maxReps = read("reps_max") || minReps;

      if (
        !isInteger(minReps, 1, 1000) ||
        !isInteger(maxReps, 1, 1000) ||
        Number(maxReps) < Number(minReps)
      ) {
        return fail(
          "Enter valid reps. Maximum reps must be at least minimum reps.",
        );
      }

      const load = read("target_load");

      if (
        load &&
        (!/^\d+(\.\d{1,2})?$/.test(load) ||
          Number(load) > 999999.99)
      ) {
        return fail("Enter a non-negative weight with up to 2 decimals.");
      }

      const rir = read("rir");
      const rest = read("rest_seconds");
      const side = read("side_override");

      if (rir && !isInteger(rir, 0, 10)) {
        return fail("RIR must be between 0 and 10.");
      }

      if (rest && !isInteger(rest, 0, 3600)) {
        return fail("Rest must be between 0 and 3,600 seconds.");
      }

      if (
        side &&
        !["both", "alternating", "each_side"].includes(side)
      ) {
        return fail("Choose a valid side setting.");
      }

      if (read("notes").length > 2000) {
        return fail("Keep set notes within 2,000 characters.");
      }

      table = "program_sets";
      parentColumn = "exercise_id";
      parentId = exerciseId;

      payload = {
        id: itemId,
        exercise_id: exerciseId,
        set_number: Number(read("set_number")),
        set_type: setType,
        reps_min: Number(minReps),
        reps_max: Number(maxReps),
        target_load: load ? Number(load) : null,
        rir: rir ? Number(rir) : null,
        rest_seconds: rest ? Number(rest) : null,
        side_override: side || null,
        notes: read("notes"),
      };

      anchor = `exercise-${exerciseId}`;
    }

    const { error } = await supabase.from(table).insert(payload);

    if (error) {
      if (error.code !== "23505") {
        return fail(
          "Could not confirm the save. Retry, or refresh to check.",
        );
      }

      // A retry of the same successful request must not add a duplicate.
      const { data: existing, error: existingError } = await supabase
        .from(table)
        .select("*")
        .eq("id", itemId)
        .eq(parentColumn, parentId)
        .maybeSingle();

      const sameItem =
        !existingError &&
        existing &&
        Object.entries(payload).every(
          ([key, value]) => existing[key] === value,
        );

      if (!sameItem) {
        return fail(
          "That exercise or set number may already exist. Refresh to check.",
        );
      }
    }
  } catch {
    return fail(
      "Could not confirm the save. Check your connection and coach sign-in, then retry.",
    );
  }

  const path = `/coach/programs/${programId}/workouts/${workoutId}`;

  revalidatePath(path);
  redirect(`${path}#${anchor}`);
}