"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createCoachAdminClient } from "@/lib/supabase/admin";

export type ProgramEditValues = {
  name: string;
  goal: string;
  description: string;
  durationWeeks: string;
  sessionsPerWeek: string;
  status: string;
};

export type ProgramEditState = {
  error: string;
  values: ProgramEditValues;
};

export async function updateProgram(
  _previousState: ProgramEditState,
  formData: FormData,
): Promise<ProgramEditState> {
  const programId = String(formData.get("programId") ?? "");

  const values: ProgramEditValues = {
    name: String(formData.get("name") ?? "").trim(),
    goal: String(formData.get("goal") ?? "").trim(),
    description: String(formData.get("description") ?? "").trim(),
    durationWeeks: String(formData.get("durationWeeks") ?? ""),
    sessionsPerWeek: String(formData.get("sessionsPerWeek") ?? ""),
    status: String(formData.get("status") ?? ""),
  };

  const fail = (error: string): ProgramEditState => ({
    error,
    values,
  });

  const validId =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

  if (!validId.test(programId)) {
    return fail("Invalid program. Return to Programs and try again.");
  }

  if (!values.name || values.name.length > 100) {
    return fail("Enter a program name between 1 and 100 characters.");
  }

  if (values.goal.length > 300) {
    return fail("Keep the goal under 300 characters.");
  }

  if (values.description.length > 2000) {
    return fail("Keep the description under 2,000 characters.");
  }

  const durationWeeks = Number(values.durationWeeks);
  const sessionsPerWeek = Number(values.sessionsPerWeek);

  if (
    !Number.isInteger(durationWeeks) ||
    durationWeeks < 1 ||
    durationWeeks > 52
  ) {
    return fail("Choose a duration between 1 and 52 whole weeks.");
  }

  if (
    !Number.isInteger(sessionsPerWeek) ||
    sessionsPerWeek < 1 ||
    sessionsPerWeek > 7
  ) {
    return fail("Choose between 1 and 7 workouts per week.");
  }

  if (!["draft", "active", "archived"].includes(values.status)) {
    return fail("Choose a valid program status.");
  }

  try {
    const admin = await createCoachAdminClient();

    const { data, error } = await admin
      .from("programs")
      .update({
        name: values.name,
        goal: values.goal,
        description: values.description,
        duration_weeks: durationWeeks,
        sessions_per_week: sessionsPerWeek,
        status: values.status,
      })
      .eq("id", programId)
      .eq("created_by", process.env.COACH_USER_ID!)
      .select("id")
      .maybeSingle();

    if (error) {
      return fail("Could not save your changes. Please try again.");
    }

    if (!data) {
      return fail("This program is unavailable to your coach account.");
    }
  } catch {
    return fail(
      "Could not confirm the save. Check your connection and coach sign-in, then retry.",
    );
  }

  revalidatePath("/coach/programs");
  revalidatePath(`/coach/programs/${programId}/details`);
  revalidatePath(`/coach/programs/${programId}/builder`);

  redirect(`/coach/programs/${programId}/builder`);
}
