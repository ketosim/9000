import Link from "next/link";
import { createCoachAdminClient } from "@/lib/supabase/admin";

type Program = {
  id: string;
  name: string;
  goal: string;
  description: string;
  duration_weeks: number;
  sessions_per_week: number;
  status: "draft" | "active" | "archived";
};

export default async function ProgramsPage() {
  const admin = await createCoachAdminClient();

  const { data, error } = await admin
    .from("programs")
    .select(
      "id, name, goal, description, duration_weeks, sessions_per_week, status",
    )
    .eq("created_by", process.env.COACH_USER_ID!)
    .order("created_at", { ascending: false });

  const programs: Program[] = data ?? [];

  return (
    <main className="hal-grid min-h-dvh bg-background px-4 py-6 text-foreground sm:px-6 sm:py-8">
      <div className="mx-auto max-w-5xl">
        <header className="flex flex-wrap items-start justify-between gap-5">
          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-hal-red-bright">
              Training library
            </p>

            <h1 className="mt-3 text-3xl font-semibold sm:text-4xl">
              Programs
            </h1>

            <p className="mt-3 text-muted">
              Your saved training programs.
            </p>
          </div>

          <Link
            href="/coach/programs/new"
            className="inline-flex min-h-12 items-center justify-center rounded-lg bg-hal-red px-5 py-3 font-semibold text-white transition focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-red-400 active:bg-hal-red-dark"
          >
            Create program
          </Link>
        </header>

        <section className="mt-10">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-xl font-semibold">All programs</h2>

            {!error && (
              <span className="text-sm text-muted">
                {programs.length}
              </span>
            )}
          </div>

          {error ? (
            <div
              role="alert"
              className="mt-5 rounded-xl border border-red-400/30 bg-red-950/30 p-5 text-sm text-red-200"
            >
              Could not load programs. Please reload this page.
            </div>
          ) : programs.length === 0 ? (
            <div className="hal-panel mt-5 rounded-xl border border-white/10 bg-panel p-6">
              <h3 className="text-lg font-semibold">
                No programs yet
              </h3>

              <p className="mt-2 text-sm text-muted">
                Create your first program to start building your
                training library.
              </p>
            </div>
          ) : (
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {programs.map((program) => (
                <Link
                  key={program.id}
                  href={`/coach/programs/${program.id}/builder`}
                  aria-label={`Open workouts for ${program.name}`}
                  className="hal-panel group block min-w-0 overflow-hidden rounded-xl border border-white/10 p-5 transition hover:border-hal-red/50 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-red-400 active:bg-panel-light sm:p-6"
                >
                  <div className="flex items-center justify-between gap-4">
                    <p className="text-xs uppercase tracking-[0.18em] text-muted">
                      {program.status}
                    </p>

                    <svg
                      aria-hidden="true"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="shrink-0 text-muted transition group-hover:text-hal-red-bright"
                    >
                      <path d="m9 5 7 7-7 7" />
                    </svg>
                  </div>

                  <h3 className="mt-3 text-2xl font-semibold leading-tight transition [overflow-wrap:anywhere] group-hover:text-hal-red-bright">
                    {program.name}
                  </h3>

                  {program.goal && (
                    <div className="mt-6">
                      <p className="text-xs text-muted">Goal</p>
                      <p className="mt-1 text-sm [overflow-wrap:anywhere]">
                        {program.goal}
                      </p>
                    </div>
                  )}

                  {program.description && (
                    <div className="mt-4">
                      <p className="text-xs text-muted">
                        Description
                      </p>
                      <p className="mt-1 whitespace-pre-line text-sm leading-relaxed text-muted [overflow-wrap:anywhere]">
                        {program.description}
                      </p>
                    </div>
                  )}

                  <dl className="mt-7 grid grid-cols-2 divide-x divide-white/10">
                    <div className="pr-4">
                      <dt className="text-xs text-muted">
                        Duration
                      </dt>
                      <dd className="mt-2 text-lg font-semibold">
                        {program.duration_weeks}{" "}
                        {program.duration_weeks === 1
                          ? "week"
                          : "weeks"}
                      </dd>
                    </div>

                    <div className="pl-4">
                      <dt className="text-xs text-muted">
                        Frequency
                      </dt>
                      <dd className="mt-2 text-lg font-semibold">
                        {program.sessions_per_week} per week
                      </dd>
                    </div>
                  </dl>
                </Link>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}